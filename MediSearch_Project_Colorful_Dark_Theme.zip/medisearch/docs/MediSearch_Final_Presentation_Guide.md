# MediSearch Final Review and Presentation Guide

> **Implementation honesty:** This guide describes the delivered starter application. It is a frontend-only demonstration using synthetic data. Run the project and test it in your environment before presenting. The supplied original Java source was not included in the files available to this generation step. `java-dsa/MediSearchDSADemo.java` is a new supplementary sample, not a replacement for the original source. Place the original source unchanged in `java-dsa/` when available.

## 1. Introduction
MediSearch is a patient-information retrieval prototype. It demonstrates how a user can search a structured patient directory by ID, name, disease, diagnosis, symptoms, doctor, room, and prescription text. The goal is to demonstrate data organisation and DSA-based retrieval—not to replace a real hospital information system.

### Objectives
- Keep fictional patient records organised in a structured JSON schema.
- Retrieve records through exact, partial, and approximate matching.
- Demonstrate selected string-search and similarity algorithms.
- Persist changes in browser-local IndexedDB.
- Support record editing and JSON/CSV data transfer.

## 2. Architecture
```mermaid
flowchart TD
  U[User] --> R[React UI and React Router]
  R --> P[Pages: Dashboard, Search, Directory, Profile, Forms]
  P --> S[Patient and Search Services]
  S --> I[IndexedDB: patients and events]
  J[src/data/patients.json] -->|first launch seed| I
  S --> A[Algorithm modules]
  A --> K[KMP / Z / Rabin-Karp]
  A --> T[Trie / Edit Distance / Jaccard]
  I --> X[JSON and CSV export]
```
React renders the interface. Vite runs the development server and creates the production build. The JSON file is the initial demo dataset. IndexedDB stores records locally; the initial seed is skipped if records already exist. Search modules implement matching logic in JavaScript because the browser cannot directly execute the separate Java source.

## 3. Dataset and storage
The bundled dataset contains exactly 150 synthetic records with IDs `P0001` through `P0150`. Each record includes identity, demographics, diagnosis, symptoms, allergies, clinician, caretaker, admission/location, history, prescriptions, administration records, lab reports, appointments, notes, and billing fields. These values are fictional and must not be used for treatment.

IndexedDB uses `patients` and `events` object stores. The initial dataset is seeded only when the patient store is empty. Updates persist after refresh in the same browser profile. This is not shared storage; clearing browser site data can remove it. Export JSON backups before experiments.

## 4. Implemented features and demo
1. **Dashboard:** live counts based on IndexedDB records and disease distribution.
2. **Search:** exact ID/name matching, partial matching across selected fields, and approximate name matching using Levenshtein distance.
3. **Autocomplete:** Trie suggestions for patient names and IDs.
4. **Directory:** browse and filter the patient list.
5. **Profile:** view personal details, admission, clinician, history, prescriptions, reports, appointments and billing.
6. **Add/edit:** validate key fields, save records to IndexedDB, and log an event.
7. **Delete:** asks for confirmation before deleting a patient.
8. **Similar cases:** ranks other patients using Jaccard overlap of symptom sets.
9. **Algorithm Lab:** executes Naive, KMP, Z-Algorithm, Rabin–Karp and Needleman–Wunsch scoring on entered text.
10. **Import/export:** export all patients to JSON and directory fields to CSV; import a JSON array with basic structural and duplicate-ID validation.

## 5. Algorithm concepts
### Exact, partial, fuzzy, similarity, graph
- **Exact search:** a complete ID or name equals the query.
- **Partial search:** the query occurs within a searchable patient text.
- **Fuzzy search:** approximate name match ranked by edit distance; labelled approximate.
- **Similarity search:** compares symptom sets, not identity.
- **Graph traversal:** visits connected vertices with BFS or DFS; a helper module is provided, but graph traversal is not currently surfaced as a dedicated UI page.

### Algorithms in this implementation
| Algorithm | File | Use | Complexity |
|---|---|---|---|
| Naive matching | `src/algorithms/naiveSearch.js` | Baseline pattern search | Worst case O(nm), O(1) extra |
| KMP + LPS | `src/algorithms/kmp.js` | Linear substring matching | O(n+m) time; O(m) LPS space |
| Z algorithm | `src/algorithms/zAlgorithm.js` | All pattern positions | O(n+m) time and space |
| Rabin–Karp | `src/algorithms/rabinKarp.js` | Rolling-hash matching with character verification | Expected efficient; worst case O(nm), O(1) auxiliary beyond output |
| Boyer–Moore bad-character rule | `src/algorithms/boyerMoore.js` | Exact search helper | Average often sublinear; worst case O(nm) for this simplified variant |
| Trie | `src/algorithms/trie.js` | Prefix autocomplete | Insert O(L); prefix walk O(P), output depends on matches |
| Levenshtein / Wagner–Fischer | `src/algorithms/editDistance.js` | Approximate name search | O(mn) time and O(mn) space |
| Jaccard | `src/algorithms/jaccardSimilarity.js` | Symptom-set overlap | O(a+b) expected with hash sets |
| Needleman–Wunsch | `src/algorithms/needlemanWunsch.js` | Global alignment score | O(mn) time and space |
| BFS / DFS | `src/algorithms/graph.js` | Relationship graph traversal helper | O(V+E) time, O(V) space |
| Multi-pattern demo | `src/algorithms/ahoCorasick.js` | Multiple term lookup helper | This simplified implementation uses repeated substring checks; not a true failure-link Aho–Corasick automaton |

Here, `n` is text length, `m` is pattern length, `a` and `b` are symptom-set sizes, `V` is graph vertices and `E` is graph edges. Aho–Corasick is implemented as a trie with failure links and output lists.

### Comparisons
- **Naive vs KMP:** naive may re-check characters; KMP uses the LPS prefix table to avoid backing up in the text.
- **KMP vs Rabin–Karp:** KMP uses prefix structure; Rabin–Karp uses rolling hashes and verifies candidate matches.
- **Z vs KMP:** Z computes prefix matches on `pattern + separator + text`; KMP follows LPS fallback links.
- **Trie vs HashMap:** a Map supports direct key lookup; a Trie supports shared-prefix traversal and autocomplete.
- **Edit distance vs Jaccard:** edit distance measures character edits; Jaccard measures set overlap.
- **Needleman–Wunsch vs Smith–Waterman:** Needleman–Wunsch aligns entire sequences; Smith–Waterman finds a best local alignment. Smith–Waterman is not implemented here.
- **BFS vs DFS:** BFS explores by layers using a queue; DFS follows a path using a stack/recursion.

## 6. Syllabus mapping — provisional
The provided syllabus image describes six modules. The table below maps relevant visible topics; exact Java-source verification remains pending because that source was not present in the inspected generation inputs.

| Module | Syllabus topic from supplied image | MediSearch decision | Status |
|---|---|---|---|
| 1 | TextHack / pattern matching; fuzzy matching; citation/follow-up concepts | Text search is directly relevant; unrelated web citation concepts excluded | Selected search concepts implemented |
| 2 | String algorithms: Naive, KMP, Rabin–Karp, multi-pattern matching, LCP/suffix arrays, sequence alignment | Naive, KMP, Rabin–Karp, Z, global alignment fit text retrieval; suffix structures omitted for scope | Partial; see algorithm files and caveat above |
| 3 | Dynamic programming: edit distance, sequence alignment, interval DP, bitmask DP | Edit distance and Needleman–Wunsch fit approximate retrieval; unrelated optimisation DP excluded | Edit distance and NW implemented |
| 4 | Network flow: Max-flow, Dinic, Ford–Fulkerson, Edmonds–Karp | No meaningful flow optimisation requirement in patient text retrieval | Excluded |
| 5 | NP-completeness, reductions, approximation, PTAS/FPTAS, APX | No relevant NP-hard optimisation task in the core application | Excluded |
| 6 | Randomised/parallel algorithms: quicksort, Miller–Rabin, hashing, reservoir sampling, parallel primitives | Hashing supports Rabin–Karp; randomised primality and parallel computation are not needed for this browser demo | Mostly excluded |

The image is a compact syllabus summary, so confirm the exact topic wording against the original high-resolution syllabus before submitting a formal mapping. Do not claim every module topic is implemented.

## 7. File-by-file guide
- `src/App.jsx`: routing and React screens.
- `src/data/patients.json`: 150 initial fictional records.
- `src/services/storageService.js`: IndexedDB setup, seed, CRUD helpers and event log.
- `src/services/patientService.js`: patient operations.
- `src/services/searchService.js`: searchable text and exact/partial/fuzzy search.
- `src/algorithms/kmp.js`: LPS preprocessing and KMP.
- `src/algorithms/zAlgorithm.js`: Z-based pattern locations.
- `src/algorithms/rabinKarp.js`: rolling-hash search and collision verification.
- `src/algorithms/naiveSearch.js`: baseline matching.
- `src/algorithms/boyerMoore.js`: simplified bad-character search.
- `src/algorithms/trie.js`: prefix suggestions.
- `src/algorithms/editDistance.js`: Levenshtein DP.
- `src/algorithms/jaccardSimilarity.js`: symptom-set overlap.
- `src/algorithms/needlemanWunsch.js`: global alignment score/table.
- `src/algorithms/graph.js`: symptom graph and BFS/DFS.
- `java-dsa/MediSearchDSADemo.java`: supplementary Java HashMap, KMP, edit-distance and Jaccard demo (new reference implementation, not the missing original).
- `src/algorithms/ahoCorasick.js`: simplified multiple-term helper, not full Aho–Corasick.
- `src/styles/global.css`: responsive dashboard design.
- `package.json`: dependencies and scripts.
- `README.md`: setup and limitation notes.

## 8. Test plan and results
**Automated execution status:** `node --test` was executed successfully: 15 algorithm/dataset/search tests passed. JavaScript/JSX syntax was also parsed with the installed TypeScript transpiler (19 source files, zero syntax diagnostics). The Vite production build and browser UI flows were not run because `npm install` timed out in this environment.

| ID | Test | Action | Expected result | Status |
|---|---|---|---|---|
| T01 | Dataset count | Inspect JSON array length | Exactly 150 | PASS — automated check |
| T02 | Unique IDs | Count distinct IDs | 150 distinct IDs P0001–P0150 | PASS — automated check |
| T03 | Initial seed | Open app twice | Does not re-seed over existing data | Code inspection only |
| T04 | Search | Search P0001 / a disease | Matching record appears | PASS — automated service test; UI needs local run |
| T05 | Add/edit/delete | Use patient forms | Changes persist and event is logged | Needs local run |
| T06 | Refresh persistence | Save then refresh | Record remains in same browser | Needs local run |
| T07 | Algorithm lab | Enter text and pattern | Actual algorithm results display | Algorithm modules PASS; UI needs local run |
| T08 | JSON export/import | Export then import JSON | Valid records load; invalid structure rejected | Needs local run |
| T09 | CSV export | Click CSV export | CSV file downloads | Needs local run |
| T10 | Production build | `npm run build` | Vite build succeeds | Not run: dependency installation timed out in this environment |\n| T11 | Clinical record entry | Add a prescription/report/appointment | Record is saved to patient and event log | Needs local run |\n| T12 | Activity history | Open Activity History | New events appear in descending time order | Needs local run |

## 9. 5–7 minute presentation script
**Introduction (40 sec):** Good morning. Our project is MediSearch, an intelligent patient-information retrieval prototype. It helps find a patient record from a structured directory using different kinds of text search.

**Problem (40 sec):** In a large directory, searching only by an exact name can fail because a user may know the patient ID, a symptom, a disease, or a doctor's name. MediSearch demonstrates a flexible retrieval approach.

**Objectives (35 sec):** Our objectives are to organise patient information, support exact and approximate search, demonstrate selected DSA algorithms, and save demo changes in browser-local storage.

**Architecture (50 sec):** The interface uses React and React Router. The initial JSON file contains 150 fictional records. IndexedDB stores the records locally. Search and algorithm modules are separate JavaScript files.

**Dataset/storage (40 sec):** Every demo record has a unique ID. The app seeds the records when the local patient store is empty. Changes can persist across refreshes in the same browser, but not automatically across devices.

**Algorithms (75 sec):** KMP uses an LPS table to avoid repeated comparisons. The Z algorithm finds pattern positions through prefix matches. Rabin–Karp uses rolling hashes and verifies possible matches. Edit distance supports approximate names, while Jaccard compares symptom sets.

**Demo (60 sec):** I will search for a patient ID, open the profile, try autocomplete, demonstrate a misspelling, add a fictional patient, refresh to check persistence, run a pattern search, and export a backup.

**Testing and limitations (35 sec):** The project should be tested locally before final submission. It is a frontend-only academic demo and is not secure or suitable for real patient information.

**Conclusion (25 sec):** MediSearch demonstrates how data structures and string algorithms can be combined with a practical React interface. Future work could include secure authentication, shared storage, role-based access, and formal testing.

## 10. 3–5 minute live demo
1. Open the local Vite URL.
2. On the dashboard, point out record counts and disease distribution.
3. Open Patient Search and enter `P0001`; open the profile.
4. Type a partial name to show Trie suggestions.
5. Try a small misspelling and point out approximate-match labels.
6. Add a fictional patient using a new name, mobile, and disease.
7. Search for the new record, refresh, and search again to check persistence.
8. Open Algorithm Lab, enter a text and pattern that exists, then a pattern that does not.
9. Open Similar Cases and change the reference patient.
10. Export JSON and CSV from Data Import / Export.

## 11. Likely viva questions
1. **What is MediSearch?** A frontend prototype for searching and browsing fictional patient records.
2. **Why this project?** It gives a practical use case for string matching and retrieval algorithms.
3. **Why React?** It supports reusable components and state-driven interfaces.
4. **Why Vite?** It provides a simple development server and production build.
5. **Why IndexedDB?** It supports structured browser-local data larger than typical preference storage.
6. **Is IndexedDB a server database?** No; it belongs to one browser profile on one device.
7. **What is KMP?** A linear-time pattern-search algorithm using an LPS prefix table.
8. **What is LPS?** Longest proper prefix that is also a suffix for each pattern prefix.
9. **Why KMP over naive search?** It avoids re-checking matched text characters after a mismatch.
10. **What is Rabin–Karp?** A rolling-hash substring search algorithm.
11. **Why verify hash matches?** Different strings can collide to the same hash.
12. **What is the Z algorithm?** It computes the longest prefix match starting at each string position.
13. **What is a Trie?** A tree-shaped prefix index useful for autocomplete.
14. **What is a HashMap?** A key-value structure with expected constant-time lookup.
15. **What is edit distance?** The minimum insertions, deletions and substitutions needed to transform one string into another.
16. **What is Jaccard similarity?** Intersection size divided by union size for two sets.
17. **Does similarity diagnose disease?** No; it only compares synthetic symptom sets.
18. **What is Needleman–Wunsch?** A dynamic-programming method for global sequence alignment.
19. **What is the difference between global and local alignment?** Global aligns both complete sequences; local finds the strongest matching region.
20. **What are BFS and DFS?** Graph traversal methods using queue-based breadth-first and stack/recursive depth-first exploration.
21. **How many initial patients are there?** 150 fictional records.
22. **How are duplicate initial seeds avoided?** Seeding occurs only when the IndexedDB patient store is empty.
23. **Does the app have real login?** No; this is a demo and mobile formatting is not identity verification.
24. **Can multiple computers share data?** Not with this frontend-only version.
25. **What happens if browser data is cleared?** Local records may be lost; backups should be exported.
26. **Why not include max-flow?** The core problem does not require network-flow optimisation.
27. **What is the limitation of the multi-pattern helper?** It uses repeated substring checks, not a full Aho–Corasick failure-link automaton.
28. **What tests have passed?** Dataset count and ID uniqueness were verified during generation; UI and build tests still need to run locally.
29. **What would you improve?** Add automated tests, full algorithm coverage, stronger import transactions and a secure shared backend if scope allows.
30. **Is it production-ready?** No. It is an academic frontend demo with fictional data.

## 12. Future scope
Possible future enhancements—not currently completed—include a secure backend, real identity verification, role-based access, encryption, audit controls, shared database synchronisation, automated unit/browser tests, accessibility testing, and deployment. Real medical data would require appropriate security, privacy, legal and clinical review.
