# MediSearch — PPT Content (10 slides)

## Slide 1 — Title
- MediSearch: Intelligent Hospital Patient Information Retrieval System
- B.Tech CSE · DSA-3 project
- Frontend demo using React, JavaScript and IndexedDB
**Speaker note:** Introduce the problem and state that all patient data is fictional.

## Slide 2 — Problem Statement
- Exact-name-only search is restrictive.
- Staff may need to locate records by ID, symptoms, disease, doctor or medicine.
- A structured search interface can improve retrieval in a demo setting.
**Speaker note:** Explain the search challenge, not a claim of real hospital deployment.

## Slide 3 — Objectives and Scope
- Search fictional patient information.
- Support exact, partial and approximate text matching.
- Demonstrate relevant DSA algorithms.
- Persist local demo changes.
- Excludes production authentication and shared backend.
**Speaker note:** Set clear boundaries for the frontend-only scope.

## Slide 4 — System Architecture
- React + React Router UI
- JSON dataset with 150 fictional records
- IndexedDB browser-local storage
- Search service and algorithm modules
- JSON / CSV export
**Speaker note:** Follow the data path from initial JSON to IndexedDB and search.

## Slide 5 — Dataset and Persistence
- IDs P0001–P0150
- Demographics, diagnosis, symptoms, clinician, prescriptions and reports
- Seed only when local store is empty
- Changes stay in the same browser profile
**Speaker note:** Mention backups and explain that local data does not synchronise.

## Slide 6 — String Search Algorithms
- Naive matching: baseline
- KMP: LPS-based fallback
- Z algorithm: prefix-match positions
- Rabin–Karp: rolling hash with verification
- Trie: name and ID autocomplete
**Speaker note:** Explain why algorithms differ and when each is useful.

## Slide 7 — Similarity and Dynamic Programming
- Levenshtein distance for approximate names
- Jaccard similarity for symptom-set overlap
- Needleman–Wunsch global alignment score
- BFS / DFS helper for relationship graph traversal
**Speaker note:** Similarity is a text comparison, not a clinical diagnosis.

## Slide 8 — Website Demonstration
- Dashboard and disease distribution
- Search results and patient profile
- Add/edit patient
- Similar cases and Algorithm Lab
- Import/export
**Speaker note:** Only show features that you have verified locally.

## Slide 9 — Testing and Complexity
- KMP: O(n+m)
- Z: O(n+m)
- Levenshtein: O(mn)
- BFS/DFS: O(V+E)
- Dataset count and unique IDs verified during generation
- UI/build tests: run locally before submission
**Speaker note:** Do not call unexecuted tests passed.

## Slide 10 — Conclusion and Future Scope
- Demonstrates DSA concepts in a practical retrieval interface
- Frontend-only and fictional-data limitations
- Future: secure authentication, shared storage, automated tests
**Speaker note:** Summarise the value and the next steps.
