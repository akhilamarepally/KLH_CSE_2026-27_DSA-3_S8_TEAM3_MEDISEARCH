# DSA-3 syllabus mapping for MediSearch

This mapping follows the supplied syllabus transcription's six-module order. Because the source Java files were not attached, “original Java” status cannot be verified.

| Module | Exact syllabus topic(s) | MediSearch application | Status | Reason |
|---|---|---|---|---|
| Module 1 — TextHack as a System | Advanced-algorithm question bank; pattern search; fuzzy matching; edit distance; document similarity; citation-flow; max-flow; scheduling; randomised algorithms | Defines retrieval as the central project problem | Conceptual context only | Search and fuzzy matching are relevant; citation flow, max-flow and scheduling are not part of patient retrieval. |
| Module 2 — String Algorithms | Naive pattern matching; KMP; failure/LPS function; Rabin–Karp; multi-pattern matching/Aho–Corasick; suffix arrays; LCP; suffix automata; edit distance; Wagner–Fischer; sequence alignment; Needleman–Wunsch; Smith–Waterman; interval DP; bitmask DP; DP on trees/subsets | Pattern search, keyword match, typo distance and alignment demonstration | Naive, KMP, Rabin–Karp, Z, Boyer–Moore, edit distance, full Aho–Corasick failure-link matching and Needleman–Wunsch implemented in JS | These directly support search demonstrations. Aho–Corasick now uses a trie, failure links and output lists. Suffix structures and unrelated DP topics are excluded. |
| Module 3 — Advanced Dynamic Programming | DP recap; Levenshtein and Damerau–Levenshtein; weighted edit distance; sequence alignment; interval DP; bitmask DP; tree/subset DP | Typo-tolerant matching and global alignment | Levenshtein and Needleman–Wunsch implemented; others excluded | Edit distance and alignment have a clear text-retrieval demonstration. Other DP families have no meaningful core use here. |
| Module 4 — Network Flow | Max-flow/min-cut; Ford–Fulkerson; Edmonds–Karp; Dinic; bipartite matching; min-cost max-flow | None in current application | Excluded | Patient lookup and symptom comparison do not require flow optimisation. |
| Module 5 — NP-Completeness and Approximation | Decision/optimisation problems; P/NP/NP-complete; reductions; 3-SAT; clique; independent set; vertex cover; subset sum; knapsack; TSP; approximation algorithms; PTAS/FPTAS/APX | None in current application | Excluded | These are valuable theory topics but do not solve the defined retrieval tasks. |
| Module 6 — Randomised and Parallel Algorithms | Las Vegas/Monte Carlo; randomised quicksort; Miller–Rabin; randomised hashing; reservoir sampling; parallel primitives; parallel sorting; GPU/distributed parallelism | None in current application | Excluded | The current local dataset and user-facing features do not need probabilistic primality, sampling or parallel execution. |

## Additional relevant data structures
- **Map / HashMap:** implemented as `createPatientIndex()` in `src/algorithms/hashIndex.js`. Current UI search directly scans current records for multi-field matching; this Map helper is an algorithm module demonstration and is not yet the central search backend.
- **Trie:** implemented in `src/algorithms/trie.js` and used to produce prefix suggestions on the search page.
- **Graph traversal:** BFS/DFS utility exists in `src/algorithms/graph.js`; no graph relationship page currently invokes it, so it is a utility demonstration rather than an integrated patient graph feature.
- **Jaccard similarity:** used on Similar Patient Cases.
- **Z algorithm and Boyer–Moore:** included as exact-pattern demonstrations.

No claim is made that all syllabus topics or the missing original Java implementation are present.
