# MediSearch — Intelligent Hospital Patient Information Retrieval System

A React + Vite frontend-only academic demonstration. It ships with **150 fictional patient records** and uses IndexedDB for browser-local persistence.

## Requirements
- Node.js 20+ recommended
- npm
- VS Code

## Run on Windows PowerShell
```powershell
cd "C:\path\to\medisearch"
npm install
npm run dev
```
Open the localhost URL Vite prints (usually `http://localhost:5173`). Stop with `Ctrl+C`.

Compile and run the supplementary Java sample (optional):
```powershell
javac java-dsa/MediSearchDSADemo.java
java -cp java-dsa MediSearchDSADemo
```

Run the algorithm and dataset tests (does not require Vite dependencies):\n```powershell\nnpm test\n```\n\nBuild production files:
```powershell
npm run build
```

## Features
- Dashboard and disease counts calculated from stored records
- Patient directory, exact/partial/fuzzy search, Trie autocomplete
- Patient profiles, add/edit/delete\n- Separate activity history, prescription, medicine-administration, laboratory-report, appointment and statistics pages
- Similar symptom sets using Jaccard similarity
- Algorithm Lab: Naive, KMP, Z, Rabin–Karp and Needleman–Wunsch
- IndexedDB seed-once persistence, JSON import/export, CSV directory export
- 150 fictional initial records (`src/data/patients.json`)

## Important limitations
All patient information is fictional. This is not a production hospital system. Demo access is not real identity verification. There is no backend, shared database, server authentication, encryption policy, or multi-user access control. Do not enter real medical information or use it for clinical decisions. IndexedDB is local to this browser and does not synchronise between devices.

## Original Java
A supplementary Java sample is provided at `java-dsa/MediSearchDSADemo.java`; it is not your original source. Place your supplied Java source in `java-dsa/` unchanged when available. JavaScript algorithm modules are separate browser-compatible implementations.
\n## Test status from generation environment\n`npm test` passed 14 tests for dataset size/IDs, exact and partial search, string algorithms, trie, similarity, alignment, multi-pattern matching and graph traversal. JSX syntax parsing passed. The Vite build and browser UI were not verified because dependency installation timed out; run `npm install` and `npm run build` locally.\n