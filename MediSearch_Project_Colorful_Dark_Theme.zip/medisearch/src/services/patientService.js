import {getAll,put,remove,logEvent} from './storageService.js';
export async function allPatients(){return (await getAll()).sort((a,b)=>a.id.localeCompare(b.id));}
export async function savePatient(p,isNew=false){const old=await allPatients();if(isNew&&old.some(x=>x.id===p.id))throw new Error('Patient ID already exists');await put('patients',p);await logEvent(p.id,isNew?'PATIENT_REGISTERED':'PROFILE_UPDATED',isNew?'Patient registered':'Patient profile updated');return p;}
export async function deletePatient(id){await remove('patients',id);await logEvent(id,'PATIENT_DELETED','Patient record deleted');}
