const DB='medisearch-db', VERSION=1;
export function openDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB,VERSION);req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains('patients'))db.createObjectStore('patients',{keyPath:'id'});if(!db.objectStoreNames.contains('events'))db.createObjectStore('events',{keyPath:'eventId'});};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
export async function getAll(store='patients'){const db=await openDB();return new Promise((res,rej)=>{const r=db.transaction(store,'readonly').objectStore(store).getAll();r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});}
export async function put(store,item){const db=await openDB();return new Promise((res,rej)=>{const r=db.transaction(store,'readwrite').objectStore(store).put(item);r.onsuccess=()=>res(item);r.onerror=()=>rej(r.error);});}
export async function remove(store,id){const db=await openDB();return new Promise((res,rej)=>{const r=db.transaction(store,'readwrite').objectStore(store).delete(id);r.onsuccess=()=>res();r.onerror=()=>rej(r.error);});}
export async function seedPatients(data){const existing=await getAll();if(existing.length)return {count:existing.length,seeded:false};const db=await openDB();return new Promise((resolve,reject)=>{const tx=db.transaction('patients','readwrite'),s=tx.objectStore('patients');data.forEach(p=>s.add(p));tx.oncomplete=()=>resolve({count:data.length,seeded:true});tx.onerror=()=>reject(tx.error);});}
export async function logEvent(patientId,type,description,relatedRecordId=''){const event={eventId:crypto.randomUUID(),patientId,at:new Date().toISOString(),type,description,relatedRecordId};await put('events',event);return event;}

// Atomically replace the patient store after all import validation has completed.
export async function replaceAllPatients(data){
  const db=await openDB();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(['patients','events'],'readwrite');
    const store=tx.objectStore('patients');
    store.clear();
    tx.objectStore('events').clear();
    for(const patient of data) store.put(patient);
    tx.oncomplete=()=>resolve(data.length);
    tx.onerror=()=>reject(tx.error);
    tx.onabort=()=>reject(tx.error||new Error('Import transaction aborted'));
  });
}
