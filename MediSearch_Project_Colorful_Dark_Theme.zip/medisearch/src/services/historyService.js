import { getAll, logEvent } from './storageService.js';
export async function eventsFor(patientId) {
  return (await getAll('events'))
    .filter(event => !patientId || event.patientId === patientId)
    .sort((a, b) => b.at.localeCompare(a.at));
}
export async function addEvent(patientId, type, description, relatedRecordId = '') {
  return logEvent(patientId, type, description, relatedRecordId);
}
