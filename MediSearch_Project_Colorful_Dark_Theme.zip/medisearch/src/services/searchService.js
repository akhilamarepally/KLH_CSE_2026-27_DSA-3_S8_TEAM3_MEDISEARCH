import { kmpSearch } from '../algorithms/kmp.js';
import { editDistance } from '../algorithms/editDistance.js';
import { createPatientIndex } from '../algorithms/hashIndex.js';

export function searchable(p) {
  return [
    p.id, p.name, p.mobile, p.disease, p.diagnosis,
    (p.symptoms || []).join(' '), (p.allergies || []).join(' '),
    p.doctor, p.specialization, p.caretaker?.name, p.caretaker?.relationship,
    p.department, p.room, p.ward, p.bed,
    (p.medicalHistory || []).map(x => x.note).join(' '),
    (p.prescriptions || []).map(x => [x.medicine, x.dosage, x.frequency, x.instructions].join(' ')).join(' '),
    (p.administrations || []).map(x => [x.medicine, x.status, x.notes].join(' ')).join(' '),
    (p.labReports || []).map(x => [x.name, x.result, x.notes].join(' ')).join(' '),
    (p.appointments || []).map(x => [x.doctor, x.purpose, x.status].join(' ')).join(' ')
  ].join(' ').toLowerCase();
}

/**
 * Search priority:
 * 1. Exact patient ID
 * 2. Exact patient name
 * 3. Patient-name matches (so searching "Rahul" does not return Meera records
 *    just because Rahul appears in an unrelated field such as a note)
 * 4. Matches in the rest of the record
 * 5. Clearly-labelled approximate name matches
 */
export function searchPatients(patients, query, mode = 'all') {
  const q = query.trim().toLowerCase();
  if (!q) return [];

  const idIndex = createPatientIndex(patients);
  const exactId = idIndex.get(q);
  if (exactId) return [{ patient: exactId, kind: 'Exact match', score: 1 }];

  const exactNames = patients.filter(p => (p.name || '').trim().toLowerCase() === q);
  if (exactNames.length) return exactNames.map(patient => ({ patient, kind: 'Exact match', score: 1 }));

  const terms = q.split(/\s+/).filter(Boolean);
  const nameMatches = patients.filter(p => {
    const name = (p.name || '').toLowerCase();
    return terms.every(term => name.includes(term) || kmpSearch(name, term) >= 0);
  });
  if (nameMatches.length) {
    return nameMatches.map(patient => ({ patient, kind: 'Name match', score: 1 }));
  }

  const partial = patients.filter(p => {
    const haystack = searchable(p);
    return terms.every(term => haystack.includes(term) || kmpSearch(haystack, term) >= 0);
  });
  if (partial.length) return partial.map(patient => ({ patient, kind: 'Partial match', score: 1 }));

  // Fuzzy matching is intentionally name-only and has a conservative threshold.
  // This avoids returning unrelated records for a query that has no good match.
  const candidates = patients.map(patient => {
    const name = (patient.name || '').toLowerCase();
    const distances = [editDistance(name, q), ...name.split(/\s+/).map(part => editDistance(part, q))];
    return { patient, kind: 'Approximate match', score: Math.min(...distances) };
  });
  return candidates
    .filter(x => x.score <= Math.max(1, Math.floor(q.length * 0.2)))
    .sort((a, b) => a.score - b.score || a.patient.name.localeCompare(b.patient.name))
    .slice(0, 10);
}
