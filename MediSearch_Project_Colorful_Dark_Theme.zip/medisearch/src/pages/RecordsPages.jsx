import React, { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { getAll, put, logEvent } from '../services/storageService.js';
import { eventsFor } from '../services/historyService.js';

function Title({title,sub}) { return <div className="page-title"><div><h2>{title}</h2><p>{sub}</p></div></div>; }
function Empty({children='No records available yet.'}) { return <div className="empty">{children}</div>; }
function RecordRows({rows, columns}) {
  if (!rows.length) return <Empty/>;
  return <div className="table-wrap"><table><thead><tr>{columns.map(c=><th key={c.label}>{c.label}</th>)}</tr></thead><tbody>{rows.map((r,i)=><tr key={r._key||r.id||r.eventId||i}>{columns.map(c=><td key={c.label}>{c.render?c.render(r):String(c.value?r[c.value]??'—':'—')}</td>)}</tr>)}</tbody></table></div>;
}
export function HistoryPage({patients}) {
  const {id}=useParams();
  const [events,setEvents]=useState([]);
  useEffect(()=>{eventsFor(id).then(setEvents).catch(console.error)},[patients,id]);
  return <><Title title={id ? `Activity history · ${id}` : 'Activity history'} sub="Chronological audit events recorded by this browser."/><section className="panel"><RecordRows rows={events} columns={[
    {label:'Date / time',render:r=>new Date(r.at).toLocaleString()},
    {label:'Patient',render:r=>r.patientId?<Link className="name-link" to={'/patient/'+r.patientId}>{patients.find(p=>p.id===r.patientId)?.name||r.patientId} ({r.patientId})</Link>:<span className="history-global">General search</span>},
    {label:'Event',value:'type'},{label:'Description',value:'description'}
  ]}/></section></>;
}
function ClinicalRecordPage({patients,refresh,kind,title,sub,fields}) {
  const [selected,setSelected]=useState(patients[0]?.id||'');
  const [form,setForm]=useState({});
  const [message,setMessage]=useState('');
  useEffect(()=>{if(!patients.some(p=>p.id===selected))setSelected(patients[0]?.id||'')},[patients,selected]);
  const rows=useMemo(()=>patients.flatMap(p=>(p[kind]||[]).map(r=>({...r,_key:p.id+'-'+(r.id||r.date||Math.random()),patientId:p.id,patientName:p.name}))),[patients,kind]);
  async function submit(e){
    e.preventDefault(); const patient=patients.find(p=>p.id===selected); if(!patient)return;
    const record={id:kind.slice(0,3).toUpperCase()+Date.now().toString().slice(-8),...form,createdAt:new Date().toISOString()};
    const updated={...patient,[kind]:[...(patient[kind]||[]),record]};
    await put('patients',updated); await logEvent(patient.id,kind.toUpperCase()+'_ADDED',title+' record added',record.id); await refresh();
    setForm({});setMessage('Saved record for '+patient.name+'.');
  }
  return <><Title title={title} sub={sub}/><section className="panel"><h3>Add record</h3><form className="form-grid" onSubmit={submit}>
    <label className="full">Patient<select value={selected} onChange={e=>setSelected(e.target.value)} required>{patients.map(p=><option key={p.id} value={p.id}>{p.id} — {p.name}</option>)}</select></label>
    {fields.map(f=><label key={f.name} className={f.full?'full':''}>{f.label}<input required={f.required!==false} type={f.type||'text'} value={form[f.name]||''} onChange={e=>setForm({...form,[f.name]:e.target.value})}/></label>)}
    <div className="full actions"><button className="primary" type="submit">Save record</button></div>
  </form>{message&&<p className="notice">{message}</p>}</section>
  <section className="panel"><h3>Existing {title.toLowerCase()}</h3><RecordRows rows={rows} columns={[
    {label:'Patient',render:r=><Link className="name-link" to={'/patient/'+r.patientId}>{r.patientName} ({r.patientId})</Link>},
    ...fields.map(f=>({label:f.label,value:f.name})),
    {label:'Record ID',value:'id'}
  ]}/></section></>;
}
export function PrescriptionsPage({patients,refresh}) { return <ClinicalRecordPage patients={patients} refresh={refresh} kind="prescriptions" title="Prescription management" sub="Add prescription entries to a fictional patient record." fields={[{name:'medicine',label:'Medicine name'},{name:'dosage',label:'Dosage'},{name:'frequency',label:'Frequency'},{name:'duration',label:'Duration'},{name:'instructions',label:'Instructions',required:false,full:true}]}/>; }
export function AdministrationPage({patients,refresh}) { return <ClinicalRecordPage patients={patients} refresh={refresh} kind="administrations" title="Medicine administration" sub="Record an administration event explicitly; prescriptions do not mean medicine was taken." fields={[{name:'medicine',label:'Medicine name'},{name:'administeredAt',label:'Date and time',type:'datetime-local'},{name:'administeredBy',label:'Recorded by'},{name:'status',label:'Status (e.g. Administered / Refused)'},{name:'notes',label:'Notes',required:false,full:true}]}/>; }
export function ReportsPage({patients,refresh}) { return <ClinicalRecordPage patients={patients} refresh={refresh} kind="labReports" title="Laboratory reports" sub="Record and review fictional lab report entries." fields={[{name:'name',label:'Report name'},{name:'date',label:'Report date',type:'date'},{name:'result',label:'Result / summary'},{name:'notes',label:'Notes',required:false,full:true}]}/>; }
export function AppointmentsPage({patients,refresh}) { return <ClinicalRecordPage patients={patients} refresh={refresh} kind="appointments" title="Appointments" sub="Add appointment entries and review the current schedule." fields={[{name:'date',label:'Appointment date',type:'date'},{name:'doctor',label:'Doctor'},{name:'purpose',label:'Purpose'},{name:'status',label:'Status',required:false}]}/>; }
export function StatisticsPage({patients}) {
 const counts=Object.entries(patients.reduce((a,p)=>(a[p.disease]=(a[p.disease]||0)+1,a),{})).sort((a,b)=>b[1]-a[1]);
 const total=(field)=>patients.reduce((n,p)=>n+(p[field]||[]).length,0);
 return <><Title title="Statistics" sub="Live summaries calculated from current browser records."/><div className="stats">{[['Total patients',patients.length],['Admitted',patients.filter(p=>!p.dischargeDate).length],['Prescriptions',total('prescriptions')],['Admin events',total('administrations')],['Lab reports',total('labReports')],['Appointments',total('appointments')]].map(([x,n])=><div className="stat" key={x}><p>{x}</p><strong>{n}</strong></div>)}</div><section className="panel"><h3>Disease distribution</h3><RecordRows rows={counts.map(([d,n])=>({d,n}))} columns={[{label:'Disease',value:'d'},{label:'Patient count',value:'n'}]}/></section></>;
}
export function WelcomePage() { return <section className="hero"><div><span className="eyebrow">MEDISEARCH · DEMO</span><h2>Intelligent patient information retrieval</h2><p>Explore fictional patient records and DSA search demonstrations. This is not a production clinical system.</p><Link className="primary" to="/login">Continue to demo →</Link></div><div className="hero-icon">✚</div></section>; }
export function LoginPage() {
 const [mobile,setMobile]=useState(''),[error,setError]=useState('');
 function go(e){e.preventDefault();if(!/^\d{10}$/.test(mobile)){setError('Enter a 10-digit mobile number, or choose Explore demo.');return;}sessionStorage.setItem('medisearch-demo-mobile',mobile);location.href='/';}
 return <><Title title="Demo access" sub="Mobile-number format validation only; no OTP is sent and identity is not verified."/><section className="panel"><form onSubmit={go} className="form-grid"><label className="full">Mobile number<input value={mobile} onChange={e=>setMobile(e.target.value)} placeholder="10-digit mobile number" inputMode="numeric"/></label>{error&&<p className="error full">{error}</p>}<div className="full actions"><button className="primary">Continue</button><Link className="secondary" to="/">Explore demo without login</Link></div></form></section></>;
}

export function MedicalHistoryPage({patients}) {
 const rows=patients.flatMap(p=>(p.medicalHistory||[]).map((r,i)=>({...r,_key:p.id+'-history-'+i,patientId:p.id,patientName:p.name})));
 return <><Title title="Medical history" sub="Browse historical notes attached to fictional patient records."/><section className="panel"><RecordRows rows={rows} columns={[{label:'Patient',render:r=><Link className="name-link" to={'/patient/'+r.patientId}>{r.patientName} ({r.patientId})</Link>},{label:'Date',value:'date'},{label:'History note',value:'note'}]}/></section></>;
}
