export function buildAhoCorasick(patterns) {
  const nodes = [{ next: new Map(), fail: 0, output: [] }];
  for (const raw of patterns) {
    const pattern = String(raw ?? '').toLowerCase();
    if (!pattern) continue;
    let state = 0;
    for (const ch of pattern) {
      if (!nodes[state].next.has(ch)) {
        nodes[state].next.set(ch, nodes.length);
        nodes.push({ next: new Map(), fail: 0, output: [] });
      }
      state = nodes[state].next.get(ch);
    }
    nodes[state].output.push(pattern);
  }
  const queue = [];
  for (const child of nodes[0].next.values()) queue.push(child);
  for (let q = 0; q < queue.length; q++) {
    const v = queue[q];
    for (const [ch, u] of nodes[v].next) {
      queue.push(u);
      let f = nodes[v].fail;
      while (f && !nodes[f].next.has(ch)) f = nodes[f].fail;
      nodes[u].fail = nodes[f].next.get(ch) ?? 0;
      nodes[u].output.push(...nodes[nodes[u].fail].output);
    }
  }
  return nodes;
}
export function multiPatternSearch(text, patterns) {
  const source = String(text ?? '').toLowerCase();
  const nodes = buildAhoCorasick(patterns);
  const matches = [];
  let state = 0;
  for (let i = 0; i < source.length; i++) {
    const ch = source[i];
    while (state && !nodes[state].next.has(ch)) state = nodes[state].fail;
    state = nodes[state].next.get(ch) ?? 0;
    for (const pattern of nodes[state].output) {
      matches.push({ pattern, at: i - pattern.length + 1 });
    }
  }
  return matches;
}
