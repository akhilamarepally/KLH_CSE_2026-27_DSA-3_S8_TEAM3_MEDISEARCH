export function zSearch(text, pattern) {
  if (!pattern) return [];
  let separator = '\u0000';
  while (text.includes(separator) || pattern.includes(separator)) separator += '\u0000';
  const s = pattern + separator + text;
  const z = Array(s.length).fill(0);
  let left = 0, right = 0;
  const out = [];
  for (let i = 1; i < s.length; i++) {
    if (i <= right) z[i] = Math.min(right - i + 1, z[i - left]);
    while (i + z[i] < s.length && s[z[i]] === s[i + z[i]]) z[i]++;
    if (i + z[i] - 1 > right) { left = i; right = i + z[i] - 1; }
    if (z[i] >= pattern.length && i > pattern.length) out.push(i - pattern.length - 1);
  }
  return out;
}
