# Original Java source

Place the supplied `MediSearch1(3).java` and associated `.class` files here unchanged when you have them. They were not available among the uploaded files inspected for this build, so this folder intentionally does not contain fabricated Java source. The browser runs the separate JavaScript implementations under `src/algorithms/`.
