import java.util.*;

/**
 * Supplementary Java DSA demonstration for MediSearch.
 * This is a new reference file, NOT the user's original MediSearch1.java.
 * Uses fictional patient examples only.
 */
public class MediSearchDSADemo {
    static class Patient {
        final String id, name, disease;
        final List<String> symptoms;
        Patient(String id, String name, String disease, String... symptoms) {
            this.id = id; this.name = name; this.disease = disease;
            this.symptoms = Arrays.asList(symptoms);
        }
        @Override public String toString() { return id + " | " + name + " | " + disease; }
    }
    static int[] buildLps(String pattern) {
        int[] lps = new int[pattern.length()]; int len = 0, i = 1;
        while (i < pattern.length()) {
            if (pattern.charAt(i) == pattern.charAt(len)) lps[i++] = ++len;
            else if (len > 0) len = lps[len - 1];
            else lps[i++] = 0;
        }
        return lps;
    }
    static int kmp(String text, String pattern) {
        if (pattern.isEmpty()) return 0;
        int[] lps = buildLps(pattern); int i = 0, j = 0;
        while (i < text.length()) {
            if (text.charAt(i) == pattern.charAt(j)) {
                i++; j++; if (j == pattern.length()) return i - j;
            } else if (j > 0) j = lps[j - 1]; else i++;
        }
        return -1;
    }
    static int editDistance(String a, String b) {
        a = a.toLowerCase(Locale.ROOT); b = b.toLowerCase(Locale.ROOT);
        int[][] dp = new int[a.length()+1][b.length()+1];
        for (int i=0;i<=a.length();i++) dp[i][0]=i;
        for (int j=0;j<=b.length();j++) dp[0][j]=j;
        for (int i=1;i<=a.length();i++) for (int j=1;j<=b.length();j++)
            dp[i][j]=Math.min(Math.min(dp[i-1][j]+1,dp[i][j-1]+1),dp[i-1][j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:1));
        return dp[a.length()][b.length()];
    }
    static double jaccard(List<String> a, List<String> b) {
        Set<String> A = new HashSet<>(), B = new HashSet<>();
        for (String x:a) A.add(x.toLowerCase(Locale.ROOT));
        for (String x:b) B.add(x.toLowerCase(Locale.ROOT));
        Set<String> union = new HashSet<>(A); union.addAll(B);
        if (union.isEmpty()) return 1.0;
        Set<String> intersection = new HashSet<>(A); intersection.retainAll(B);
        return (double)intersection.size()/union.size();
    }
    public static void main(String[] args) {
        List<Patient> patients = List.of(
            new Patient("P0001", "Rahul Sharma", "Asthma", "wheezing", "cough"),
            new Patient("P0002", "Aadhya Reddy", "Migraine", "headache", "nausea"),
            new Patient("P0003", "Meera Patel", "Asthma", "cough", "shortness of breath")
        );
        Map<String, Patient> idIndex = new HashMap<>();
        for (Patient p : patients) idIndex.put(p.id.toLowerCase(Locale.ROOT), p);
        System.out.println("Exact HashMap lookup: " + idIndex.get("p0001"));
        System.out.println("KMP index of 'asthma': " + kmp("rahul has asthma", "asthma"));
        System.out.println("Edit distance (Rahul/Rahulx): " + editDistance("Rahul", "Rahulx"));
        System.out.printf(Locale.ROOT, "Symptom Jaccard (P0001/P0003): %.2f%n", jaccard(patients.get(0).symptoms, patients.get(2).symptoms));
    }
}
