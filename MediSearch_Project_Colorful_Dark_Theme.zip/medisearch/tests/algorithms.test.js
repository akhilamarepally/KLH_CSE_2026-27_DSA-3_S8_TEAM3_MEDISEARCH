import test from 'node:test';
import assert from 'node:assert/strict';
import { naiveSearch } from '../src/algorithms/naiveSearch.js';
import { kmpSearch, buildLPS } from '../src/algorithms/kmp.js';
import { zSearch } from '../src/algorithms/zAlgorithm.js';
import { rabinKarp } from '../src/algorithms/rabinKarp.js';
import { boyerMoore } from '../src/algorithms/boyerMoore.js';
import { editDistance } from '../src/algorithms/editDistance.js';
import { jaccard } from '../src/algorithms/jaccardSimilarity.js';
import { Trie } from '../src/algorithms/trie.js';
import { multiPatternSearch } from '../src/algorithms/ahoCorasick.js';
import { needlemanWunsch } from '../src/algorithms/needlemanWunsch.js';
import { traverseGraph } from '../src/algorithms/graph.js';
import { createPatientIndex } from '../src/algorithms/hashIndex.js';
import { searchPatients } from '../src/services/searchService.js';
import patients from '../src/data/patients.json' with { type: 'json' };

test('dataset contains 150 records with unique IDs', () => {
  assert.equal(patients.length, 150);
  assert.equal(new Set(patients.map(p => p.id)).size, 150);
  assert.equal(patients[0].id, 'P0001');
  assert.equal(patients.at(-1).id, 'P0150');
});
test('naive, KMP, Z, Rabin-Karp and Boyer-Moore find a present pattern', () => {
  const text = 'aabaacaadaabaaba';
  assert.equal(naiveSearch(text, 'aaba'), 0);
  assert.equal(kmpSearch(text, 'aaba'), 0);
  assert.deepEqual(zSearch(text, 'aaba'), [0, 9, 12]);
  assert.deepEqual(rabinKarp(text, 'aaba'), [0, 9, 12]);
  assert.equal(boyerMoore(text, 'aaba'), 0);
});
test('search algorithms handle missing and empty patterns', () => {
  assert.equal(naiveSearch('abc', 'xyz'), -1);
  assert.equal(kmpSearch('abc', 'xyz'), -1);
  assert.deepEqual(zSearch('abc', 'xyz'), []);
  assert.deepEqual(rabinKarp('abc', 'xyz'), []);
  assert.equal(boyerMoore('abc', 'xyz'), -1);
  assert.equal(kmpSearch('abc', ''), 0);
});
test('KMP builds expected LPS table', () => assert.deepEqual(buildLPS('ababaca'), [0,0,1,2,3,0,1]));
test('Z search handles delimiter-like content', () => assert.deepEqual(zSearch('a$b$a$b', '$b'), [1,5]));
test('Levenshtein edit distance', () => {
  assert.equal(editDistance('kitten', 'sitting'), 3);
  assert.equal(editDistance('Rahul', 'Rahul'), 0);
});
test('Jaccard similarity compares sets', () => {
  assert.equal(jaccard(['a','b'], ['b','c']), 1/3);
  assert.equal(jaccard([], []), 1);
});
test('Trie suggests matching prefixes', () => {
  const t = new Trie(); t.insert('Rahul Sharma'); t.insert('Rahul Rao'); t.insert('P0001');
  assert.deepEqual(t.suggest('rah'), ['Rahul Sharma','Rahul Rao']);
});
test('Aho-Corasick multi-pattern matching reports actual positions', () => {
  assert.deepEqual(multiPatternSearch('ushers', ['he','she','hers']).sort((a,b)=>a.at-b.at), [
    {pattern:'she',at:1},{pattern:'he',at:2},{pattern:'hers',at:2}
  ]);
});
test('Needleman-Wunsch returns a numeric global alignment score', () => {
  const result=needlemanWunsch('abc','abc');
  assert.equal(result.score, 6);
  assert.equal(result.table.length, 4);
});
test('BFS and DFS visit reachable graph nodes', () => {
  const graph={A:['B','C'],B:['D'],C:[],D:[]};
  assert.deepEqual(traverseGraph(graph,'A','BFS'),['A','B','C','D']);
  assert.deepEqual(new Set(traverseGraph(graph,'A','DFS')),new Set(['A','B','C','D']));
});

test('Map-based patient ID index returns exact record', () => {
  const index=createPatientIndex(patients);
  assert.equal(index.size,150);
  assert.equal(index.get('p0001').id,'P0001');
});
test('central search supports exact ID and partial symptom search', () => {
  assert.equal(searchPatients(patients,'P0001')[0].patient.id,'P0001');
  const disease=patients[0].disease;
  assert.ok(searchPatients(patients,disease).length>0);
});
test('central search labels misspelled names as approximate when within threshold', () => {
  const name=patients[0].name;
  const typo=name.slice(0,-1)+(name.endsWith('x')?'y':'x');
  const results=searchPatients(patients,typo);
  assert.ok(results.some(r=>r.patient.id===patients[0].id && r.kind==='Approximate match'));
});

test('central search supports multi-term queries across different fields', () => {
  const patient=patients[0];
  const results=searchPatients(patients, patient.name.split(' ')[0]+' '+patient.disease);
  assert.ok(results.some(r=>r.patient.id===patient.id));
});
